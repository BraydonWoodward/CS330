var searchData=
[
  ['getting_20started_0',['Getting started',['../quick_guide.html',1,'']]]
];
