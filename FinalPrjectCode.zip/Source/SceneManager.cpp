///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}


/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
	// destroy the created OpenGL textures
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
* DefineObjectMaterials()
 *
* This method is used for configuring the various material
* settings for all of the objects in the 3D scene.
***********************************************************/

void SceneManager::DefineObjectMaterials()
{

	OBJECT_MATERIAL cementMaterial;
	cementMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	cementMaterial.ambientStrength = 0.2f;
	cementMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	cementMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
	cementMaterial.shininess = 0.5;
	cementMaterial.tag = "cement";
	m_objectMaterials.push_back(cementMaterial);

	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.4f, 0.3f, 0.1f);
	woodMaterial.ambientStrength = 0.2f;
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
	woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.shininess = 0.3;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	glassMaterial.ambientStrength = 0.4f;
	glassMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	glassMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	glassMaterial.shininess = 90.0;
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);

	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.ambientColor = glm::vec3(0.25f, 0.25f, 0.25f);
	woodMaterial.ambientStrength = 0.25f;
	plasticMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	plasticMaterial.specularColor = glm::vec3(0.7f, 0.7f, 0.7f); 
	plasticMaterial.shininess = 76.8f;
	plasticMaterial.tag = "plastic";
	m_objectMaterials.push_back(plasticMaterial);

	OBJECT_MATERIAL metalMaterial;
	metalMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	metalMaterial.ambientStrength = 0.3f;
	metalMaterial.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f);
	metalMaterial.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
	metalMaterial.shininess = 128.0f;
	metalMaterial.tag = "metal";
	m_objectMaterials.push_back(metalMaterial);

	OBJECT_MATERIAL screenMaterial;
	screenMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	screenMaterial.ambientStrength = 0.5f;
	screenMaterial.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f);
	screenMaterial.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
	screenMaterial.shininess = 64.0f;
	screenMaterial.tag = "screen";
	m_objectMaterials.push_back(screenMaterial);

	OBJECT_MATERIAL wallPaintMaterial;
	wallPaintMaterial.ambientColor = glm::vec3(0.6f, 0.6f, 0.6f); 
	wallPaintMaterial.ambientStrength = 0.3f;
	wallPaintMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f); 
	wallPaintMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f); 
	wallPaintMaterial.shininess = 10.0f;                         
	wallPaintMaterial.tag = "wallpaint";
	m_objectMaterials.push_back(wallPaintMaterial);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is used for setting up the scene light sources
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Set global ambient light color
	m_pShaderManager->setVec3Value("globalAmbientColor", 0.2f, 0.2f, 0.2f);

	// Light source 1 (Directional Light)
	m_pShaderManager->setVec3Value("lightSources[0].position", 3.0f, 14.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[0].direction", -0.2f, -1.0f, -0.3f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.5f, 0.5f, 0.5f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setFloatValue("lightSources[0].constant", 0.0f);
	m_pShaderManager->setFloatValue("lightSources[0].linear", 0.0f);
	m_pShaderManager->setFloatValue("lightSources[0].quadratic", 0.0f);
	m_pShaderManager->setFloatValue("lightSources[0].innerCutoff", 0.0f);
	m_pShaderManager->setFloatValue("lightSources[0].outerCutoff", 0.0f);

	// Light source 2 (Point Light)
	m_pShaderManager->setVec3Value("lightSources[1].position", 3.0f, 14.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.8f, 0.8f, 0.8f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setFloatValue("lightSources[1].constant", 1.0f);
	m_pShaderManager->setFloatValue("lightSources[1].linear", 0.09f);
	m_pShaderManager->setFloatValue("lightSources[1].quadratic", 0.032f);
	m_pShaderManager->setFloatValue("lightSources[1].innerCutoff", 0.0f);
	m_pShaderManager->setFloatValue("lightSources[1].outerCutoff", 0.0f);

	// Light source 3 (Spotlight)
	m_pShaderManager->setVec3Value("lightSources[2].position", 0.0f, 10.0f, 10.0f);
	m_pShaderManager->setVec3Value("lightSources[2].direction", 0.0f, 0.0f, -1.0f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setFloatValue("lightSources[2].constant", 1.0f);
	m_pShaderManager->setFloatValue("lightSources[2].linear", 0.09f);
	m_pShaderManager->setFloatValue("lightSources[2].quadratic", 0.032f);
	m_pShaderManager->setFloatValue("lightSources[2].innerCutoff", cos(glm::radians(12.5f)));
	m_pShaderManager->setFloatValue("lightSources[2].outerCutoff", cos(glm::radians(17.5f)));

	// Light source 4 (Window diffused light)
	m_pShaderManager->setVec3Value("lightSources[3].position", 0.0f, 10.0f, -2.0f);
	m_pShaderManager->setVec3Value("lightSources[3].direction", 1.0f, -0.5f, -0.3f);
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.3f, 0.1f, 0.3f); // Purple ambient color
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.6f, 0.2f, 0.6f); // Purple diffuse color
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.7f, 0.5f, 0.7f); // Slightly specular purple
	m_pShaderManager->setFloatValue("lightSources[3].constant", 0.0f);
	m_pShaderManager->setFloatValue("lightSources[3].linear", 0.0f);
	m_pShaderManager->setFloatValue("lightSources[3].quadratic", 0.0f);
	m_pShaderManager->setFloatValue("lightSources[3].innerCutoff", 0.0f);
	m_pShaderManager->setFloatValue("lightSources[3].outerCutoff", 0.0f);

	// Light source 5 (Directional Light - Monitor 1)
	glm::vec3 monitor1Pos = glm::vec3(4.3f, 5.8f, -1.0f);
	glm::vec3 monitor1Dir = glm::vec3(0.0f, 0.0f, 1.0f); // Assuming the monitor is facing along the positive Z direction
	m_pShaderManager->setVec3Value("lightSources[0].position", monitor1Pos);
	m_pShaderManager->setVec3Value("lightSources[0].direction", monitor1Dir);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.5f, 0.5f, 0.5f); // Increased ambient intensity
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 1.0f, 1.0f, 1.0f); // Increased diffuse intensity
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 1.0f, 1.0f, 1.0f); // Increased specular intensity
	m_pShaderManager->setFloatValue("lightSources[0].constant", 1.0f);
	m_pShaderManager->setFloatValue("lightSources[0].linear", 0.09f);
	m_pShaderManager->setFloatValue("lightSources[0].quadratic", 0.032f);
	m_pShaderManager->setFloatValue("lightSources[0].innerCutoff", 0.0f);
	m_pShaderManager->setFloatValue("lightSources[0].outerCutoff", 0.0f);

	// Light source 6 (Directional Light - Monitor 2)
	glm::vec3 monitor2Pos = glm::vec3(1.0f, 5.5f, -1.2f);
	glm::vec3 monitor2Dir = glm::vec3(0.0f, 0.0f, 1.0f); // Assuming the monitor is facing along the positive Z direction
	m_pShaderManager->setVec3Value("lightSources[1].position", monitor2Pos);
	m_pShaderManager->setVec3Value("lightSources[1].direction", monitor2Dir);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.5f, 0.5f, 0.5f); // Increased ambient intensity
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 1.0f, 1.0f, 1.0f); // Increased diffuse intensity
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 1.0f, 1.0f, 1.0f); // Increased specular intensity
	m_pShaderManager->setFloatValue("lightSources[1].constant", 1.0f);
	m_pShaderManager->setFloatValue("lightSources[1].linear", 0.09f);
	m_pShaderManager->setFloatValue("lightSources[1].quadratic", 0.032f);
	m_pShaderManager->setFloatValue("lightSources[1].innerCutoff", 0.0f);
	m_pShaderManager->setFloatValue("lightSources[1].outerCutoff", 0.0f);

	// Light source 7 (Directional Light - Monitor 3)
	glm::vec3 monitor3Pos = glm::vec3(-3.0f, 5.0f, -1.5f);
	glm::vec3 monitor3Dir = glm::vec3(0.0f, 0.0f, 1.0f); // Assuming the monitor is facing along the positive Z direction
	m_pShaderManager->setVec3Value("lightSources[2].position", monitor3Pos);
	m_pShaderManager->setVec3Value("lightSources[2].direction", monitor3Dir);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.5f, 0.5f, 0.5f); // Increased ambient intensity
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 1.0f, 1.0f, 1.0f); // Increased diffuse intensity
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 1.0f, 1.0f, 1.0f); // Increased specular intensity
	m_pShaderManager->setFloatValue("lightSources[2].constant", 1.0f);
	m_pShaderManager->setFloatValue("lightSources[2].linear", 0.09f);
	m_pShaderManager->setFloatValue("lightSources[2].quadratic", 0.032f);
	m_pShaderManager->setFloatValue("lightSources[2].innerCutoff", 0.0f);
	m_pShaderManager->setFloatValue("lightSources[2].outerCutoff", 0.0f);

	m_pShaderManager->setBoolValue("bUseLighting", true);

}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue/255;
	currentColor.g = greenColorValue/255;
	currentColor.b = blueColorValue/255;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/

	bool bReturn = false;

	// light wood texture for desk top
	bReturn = CreateGLTexture(
		"textures/light-wood-2048x2048.png", "desktop");
	

	// dark wood texture for floor
	bReturn = CreateGLTexture(
		"textures/dark-wood-2048x2048.png", "floor");
	

	// stone texture for wall
	bReturn = CreateGLTexture(
		"textures/concrete_seamless_texture_6820.jpg", "wall");

	// white ceiling texture 
	bReturn = CreateGLTexture(
		"textures/graphical-white-jacquard-1106-in-architextures.jpg", "ceiling");

	// metal texture for monitors and mount
	bReturn = CreateGLTexture(
		"textures/plain-black-texture-111-in-architextures.jpg", "metal");

	// designed texture for mousepad
	bReturn = CreateGLTexture(
		"textures/fabric_seamless_texture_2510.jpg", "mousepad");

	// metal texture for window
	bReturn = CreateGLTexture(
		"textures/seamless-clear-glass-texture.jpg", "window");

	// plastic texture 
	bReturn = CreateGLTexture(
		"textures/plain-black-flat-1969-in-architextures.jpg", "plastic");

	// right monitor texture 
	bReturn = CreateGLTexture(
		"textures/RightMonitor.gif", "right-monitor");

	// left monitor texture 
	bReturn = CreateGLTexture(
		"textures/LeftMonitor.gif", "left-monitor");

	// middle monitor texture 
	bReturn = CreateGLTexture(
		"textures/MiddleMonitor.jpg", "middle-monitor");

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load the textures, materials, and light setup for the 3D scene
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadCylinderMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/

	/*******************************Wall & Floor Planes*********************************/

	//Scale for each of the walls
	scaleXYZ = glm::vec3(20.0f, 1.0f, 20.0f);

	// set the XYZ rotations (Floor, Back wall, left wall, right wall, ceiling)
	std::vector<float >Xrotations = { 0.0f, 90.0f, 90.0f, 90.0f, 0.0f};
	std::vector<float >Yrotations = { 0.0f, 0.0f, 90.0f, 90.0f, 0.0f };
	std::vector<float >Zrotations = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	


	// Positions for 4 planes
	glm::vec3 wallPositions[] = {
		glm::vec3(-12.5f, -3.3f, 16.0f),//floor
		glm::vec3(-12.5f, 5.0f, -3.0f),//back wall
		glm::vec3(-32.5f, 5.0f, 16.0f),//left wall
		glm::vec3(7.5f, 5.0f, 16.0f),//right wall
		glm::vec3(-12.5f, 22.0f, 16.0f)//ceiling
	};



	// Loop to draw each plane iterating through the position vector
	for (int i = 0; i < 5; i++) {
		positionXYZ = wallPositions[i];

		// Assign rotation values before calling the function
		XrotationDegrees = Xrotations[i];
		YrotationDegrees = Yrotations[i];
		ZrotationDegrees = Zrotations[i];

		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ
		);

		if (i == 0) // texture the floor
		{
			SetShaderTexture("floor");
		}
		else if (i == 4) // texture the ceiling
		{
			SetShaderTexture("ceiling");
		}
		else // texture the walls
		{
			SetShaderTexture("wall");
		}

		SetShaderMaterial("wallpaint");
		m_basicMeshes->DrawPlaneMesh();
	}

	/*******************************desk top box***********************************/
	// set the XYZ scale 
	scaleXYZ = glm::vec3(14.0f, .2f, 4.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f,3.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// light wood texture
	SetShaderTexture("desktop");
	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/****************************desk bottom box************************************/

	// set the XYZ scale 
	scaleXYZ = glm::vec3(13.9f, .4f, 3.9f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 2.7f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(255, 255, 255, 1);
	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	
	/*******************************desk vertical box legs*********************************/

	//Scale for each of the legs
	scaleXYZ = glm::vec3(0.5f, 6.0f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;


	// Positions for 4 boxes  
	glm::vec3 boxPositions[] = {
		glm::vec3(6.5f, -0.4f, 1.5f),//front right leg
		glm::vec3(6.5f, -0.4f, -1.7f),//back right leg
		glm::vec3(-6.5f, -0.4f, 1.5f),//front left leg
		glm::vec3(-6.5f, -0.4f, -1.7f)//back left leg
	};

	   //Loop to draw each box iterating through the position vector
		for (int i = 0; i < 4; i++) {
			scaleXYZ,
			positionXYZ = boxPositions[i];
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			SetShaderColor(255, 255, 255, 1.0f);
			SetShaderMaterial("metal");
			m_basicMeshes->DrawBoxMesh();
		}

		/****************************mouse-pad plane************************************/

		// set the XYZ scale 
		scaleXYZ = glm::vec3(4.5f, 1.0f, 1.5f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(0.0f, 3.15f, .15f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("mousepad");
		SetShaderMaterial("wood");

		// draw the mesh with transformation values
		m_basicMeshes->DrawPlaneMesh();

		/****************************monitor mounts (right & middle monitor)************************************/

		// render wall plate
		// set the XYZ scale 
		scaleXYZ = glm::vec3(1.5f, 0.3f, 0.7f);

		// set the XYZ rotation for the mesh
		XrotationDegrees =90.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(3.0f, 5.5f, -2.9f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("metal");
		SetShaderMaterial("metal");

		// draw the mesh with transformation values
		m_basicMeshes->DrawBoxMesh();

		// render the back mounts
		// set the XYZ scale 
		scaleXYZ = glm::vec3(0.5f, 0.5f, 0.2f);

		// set the XYZ rotations {right monitor, middle monitor}
		std::vector<float >Xrotations_mount = {0.0f, 0.0f};
		std::vector<float >Yrotations_mount = {-15.0f, 0.0f};
		std::vector<float >Zrotations_mount  = {0.0f, 0.0f};

		// Positions for 2 boxes  
			glm::vec3 mountPositions[] = {
			glm::vec3(4.3f, 5.8f, -1.15f),// right monitor
			glm::vec3(1.0f, 5.5f, -1.35f),// middle monitor
		};

		for (int i = 0; i < 2; i++) {
			positionXYZ = mountPositions[i];
			XrotationDegrees = Xrotations_mount[i];
			YrotationDegrees = Yrotations_mount[i];
			ZrotationDegrees = Zrotations_mount[i];
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			SetShaderTexture("metal");
			SetShaderMaterial("metal");
			m_basicMeshes->DrawBoxMesh();
		}

		// render the back mount joints
		// set the XYZ scale 
		scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// Positions for 3 spheres
		glm::vec3 jointPositions[] = {
		glm::vec3(4.3f, 5.8f, -2.0f),// right monitor
		glm::vec3(1.0f, 5.5f, -2.2f),// middle monitor
		glm::vec3(3.0f, 5.5f, -2.4f)// connecting joint
		};

		for (int i = 0; i < 3; i++) {
			positionXYZ = jointPositions[i];
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			SetShaderTexture("metal");
			SetShaderMaterial("metal");
			m_basicMeshes->DrawSphereMesh();
		}

		// render the mount arms
		// set the XYZ scale 
		glm::vec3 armsScale[] = {
			glm::vec3(0.12f, 0.7f, 0.1f),// right arm
			glm::vec3(0.12f, 0.75f, 0.1f),// middle arm
			glm::vec3(0.12f, 1.15f, 0.1f),// right connecting arm
			glm::vec3(0.12f, 1.75f, 0.1f),// left connecting arm
			glm::vec3(0.12f, 0.3f, 0.1f)// mount connectin arm
		};

		// set the XYZ rotations {right arm, middle arm, right connecting arm, left conencting arm, mount connecting arm}
		std::vector<float >Xrotations_arm = { 90.0f, 90.0f, 15.0f, -6.0f, 90.0f };
		std::vector<float >Yrotations_arm = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
		std::vector<float >Zrotations_arm = { 0.0f, 0.0f, -75.0f, -90.0f, 0.0f };


		// Positions for 5 cylinders
		glm::vec3 armPositions[] = {
		glm::vec3(4.3f, 5.8f, -1.9f),// right arm
		glm::vec3(1.0f, 5.5f, -2.1f),// middle arm
		glm::vec3(3.1f, 5.5f, -2.35f),// right connecting arm
		glm::vec3(1.1f, 5.5f, -2.2f),// left connecting arm
		glm::vec3(3.0f, 5.5f, -2.8f)// mount connectin arm
		};

		// draw spheres
		for (int i = 0; i < 5; i++) {
			scaleXYZ = armsScale[i];
			positionXYZ = armPositions[i];
			XrotationDegrees = Xrotations_arm[i];
			YrotationDegrees = Yrotations_arm[i];
			ZrotationDegrees = Zrotations_arm[i];
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			SetShaderTexture("metal");
			SetShaderMaterial("metal");
			m_basicMeshes->DrawCylinderMesh();
		}


		/****************************back window mesh************************************/

		// set the XYZ scale 
		scaleXYZ = glm::vec3(8.0f, 5.0f, 8.0f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 90.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(-13.0f, 9.0f, -2.6f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("window");
		SetShaderMaterial("glass");

		// draw the mesh with transformation values
		m_basicMeshes->DrawPlaneMesh();

/*******************************window sill*********************************/

       //Scale for each of the legs
		scaleXYZ = glm::vec3(0.8f, 16.0f, 0.3f);

		// set the XYZ rotations 
		std::vector<float >Xrotations1 = { 0.0f, 0.0f, 0.0f, 0.0f };
		std::vector<float >Yrotations1 = { 0.0f, 0.0f, 0.0f, 0.0f };
		std::vector<float >Zrotations1 = { 0.0f, 0.0f, 90.0f, 90.0f };


		// Positions for 4 boxes  
		glm::vec3 sillPositions[] = {
			glm::vec3(-21.4f, 9.0f, -2.5f),//left side
			glm::vec3(-4.6f, 9.0f, -2.5f),// right side
			glm::vec3(-13.0f, 1.4f,-2.5f),// bottom side
			glm::vec3(-13.0f, 16.6f, -2.5f)// top side
		};

		//Loop to draw each box iterating through the position vector
		for (int i = 0; i < 4; i++) {
			scaleXYZ,
			positionXYZ = sillPositions[i];
			SetTransformations(scaleXYZ,
				XrotationDegrees = Xrotations1[i],
				YrotationDegrees = Yrotations1[i],
				ZrotationDegrees = Zrotations1[i], 
				positionXYZ);
			SetShaderTexture("ceiling");
			SetShaderMaterial("wallpaint");
			m_basicMeshes->DrawBoxMesh();
		}

/****************************monitor 1 (right)************************************/
		// render the screen
		// set the XYZ scale 
		scaleXYZ = glm::vec3(2.2f, 3.0f, 1.1f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 75.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 90.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(4.3f, 5.8f, -1.0f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("middle-monitor");
		SetShaderMaterial("screen");

		// draw the mesh with transformation values
		m_basicMeshes->DrawPlaneMesh();

		// render the frame
		// set the XYZ scale 
		scaleXYZ = glm::vec3(2.3f, 4.5f, 0.1f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = -15.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(4.3f, 5.8f, -1.06f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("plastic");
		SetShaderMaterial("plastic");

		// draw the mesh with transformation values
		m_basicMeshes->DrawBoxMesh();

/****************************monitor 2 (middle)************************************/
		// render the screen
		// set the XYZ scale 
		scaleXYZ = glm::vec3(1.9f, 1.0f, 1.1f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 90.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(1.0f, 5.5f, -1.2f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("right-monitor");
		SetShaderMaterial("screen");

		// draw the mesh with transformation values
		m_basicMeshes->DrawPlaneMesh();

		// render the frame
		// set the XYZ scale 
		scaleXYZ = glm::vec3(2.3f, 3.9f, 0.1f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 90.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(1.0f, 5.5f, -1.26f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("plastic");
		SetShaderMaterial("plastic");

		// draw the mesh with transformation values
		m_basicMeshes->DrawBoxMesh();

/****************************monitor 3 (left)************************************/
		// render the screen
		// set the XYZ scale 
		scaleXYZ = glm::vec3(2.7f, 1.0f, 1.8f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 90.0f;
		YrotationDegrees = 15.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(-3.8f, 5.5f, -1.0f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("left-monitor");
		SetShaderMaterial("screen");

		// draw the mesh with transformation values
		m_basicMeshes->DrawPlaneMesh();

		// render the frame
		// set the XYZ scale 
		scaleXYZ = glm::vec3(3.7f, 5.5f, 0.1f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 15.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 90.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(-3.8f, 5.5f, -1.06f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("plastic");
		SetShaderMaterial("plastic");

		// draw the mesh with transformation values
		m_basicMeshes->DrawBoxMesh();

		// render the monitor stand
		// set the XYZ scale 
		scaleXYZ = glm::vec3(0.4f, 2.0f, 0.1f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 15.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(-3.8f, 4.0f, -1.25f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("metal");
		SetShaderMaterial("plastic");

		// draw the mesh with transformation values
		m_basicMeshes->DrawBoxMesh();

		// render the monitor base
		// set the XYZ scale 
		scaleXYZ = glm::vec3(2.0f, 0.1f, 1.0f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 15.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(-3.8f, 3.18f, -1.25f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("metal");
		SetShaderMaterial("plastic");

		// draw the mesh with transformation values
		m_basicMeshes->DrawBoxMesh();

		// render the connector
		// set the XYZ scale 
		scaleXYZ = glm::vec3(0.5f, 0.5f, 0.1f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 15.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(-3.8f, 4.9f, -1.15f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("plastic");
		SetShaderMaterial("cement");

		// draw the mesh with transformation values
		m_basicMeshes->DrawBoxMesh();

/****************************keyboard************************************/
		// render the case
		// set the XYZ scale 
		scaleXYZ = glm::vec3(1.7f, 0.1f, 0.55f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(0.21f, 3.2f, 0.7f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("plastic");
		SetShaderMaterial("metal");

		// draw the mesh with transformation values
		m_basicMeshes->DrawBoxMesh();

		// render the keys

		// set scale for each key
		glm::vec3 keyScale = glm::vec3(0.09f, 0.06f, 0.09f); // Reduced scale

		// set starting position for the keys
		glm::vec3 startPosition = glm::vec3(-0.5f, 3.3f, 0.5f); // Adjusted position

		// set the offset between keys
		float xOffset = 0.12f;
		float zOffset = 0.12f;

		// Loop to create 4 rows of 13 keys
		for (int row = 0; row < 4; ++row)
		{
			for (int col = 0; col < 13; ++col)
			{
				// Calculate the position for the current key
				glm::vec3 keyPosition = startPosition + glm::vec3(col * xOffset, 0.0f, row * zOffset);

				// Set transformations for the key
				SetTransformations(keyScale, 0.0f, 0.0f, 0.0f, keyPosition);

				// Set texture and material for the keys
				SetShaderTexture("plastic");
				SetShaderMaterial("plastic");

				// Draw the key
				m_basicMeshes->DrawBoxMesh();
			}
		}

/****************************mouse************************************/
		// render the mouse base
		// set the XYZ scale 
		scaleXYZ = glm::vec3(0.24f, 0.15f, 0.4f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(2.0f, 3.2f, 0.7f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("plastic");
		SetShaderMaterial("plastic");

		// draw the mesh with transformation values
		m_basicMeshes->DrawBoxMesh();

		// render the mouse left button
		// set the XYZ scale 
		scaleXYZ = glm::vec3(0.11f, 0.01f, 0.2f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(1.94f, 3.28f, 0.6f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("plastic");
		SetShaderMaterial("metal");

		// draw the mesh with transformation values
		m_basicMeshes->DrawBoxMesh();

		// render the mouse right button
		// set the XYZ scale 
		scaleXYZ = glm::vec3(0.11f, 0.01f, 0.2f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(2.06f, 3.28f, 0.6f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("plastic");
		SetShaderMaterial("metal");

		// draw the mesh with transformation values
		m_basicMeshes->DrawBoxMesh();

		// render the mouse scroll wheel
		// set the XYZ scale 
		scaleXYZ = glm::vec3(0.05f, 0.03f, 0.07);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 90.0f;
		YrotationDegrees = 90.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(1.985f, 3.234f, 0.55f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderTexture("plastic");
		SetShaderMaterial("plastic");

		// draw the mesh with transformation values
		m_basicMeshes->DrawCylinderMesh();

}